#!/bin/bash
if /usr/bin/find /home/itc/regsitel > /dev/null ; then
	/bin/chmod +x /home/itc/sitel
	/bin/chmod +x /home/itc/txfinder
	/bin/chmod +x /home/itc/regsitel
	/bin/rm -rf /home/itc/*.lic
	echo
	echo -n "Ingrese la licencia a registrar: "
	read
	LICENCIA=$REPLY
	echo
	echo -n "Ingrese el Nombre del Prestador: "
	read
	PRESTADOR=$REPLY
	echo
	echo -n "Ingrese el dir. de trabajo de Sitel (Terms, Ej. /home/itc) : "
	read
	TERMS=$REPLY
	if /usr/bin/find $TERMS/tx  > /dev/null ; then
			if /usr/bin/find $TERMS/term*  > /dev/null ; then
				echo "/home/itc/regsitel -r 192.168.10.41 -p 8000 -l $LICENCIA -n '"$PRESTADOR"' -t "$TERMS" -s /home/itc/sitel -a -ttcp -a -x10 -a -l/var/log/regsitel.log" > /etc/cron.weekly/regsitel ; /bin/chmod +x /etc/cron.weekly/regsitel ; /etc/cron.weekly/regsitel
			else
				echo
				echo "ERROR: El dir. de trabajo de Sitel no tiene la estructura correcta."
				echo "No existe ninguna terminal creada"
				echo
			fi
		else
		echo
		echo "ERROR: El dir. de trabajo de Sitel no tiene la estructura correcta."
		echo "No existe el directorio tx"
		echo
	fi
	else
		echo
		echo "ERROR: Antes debe copiar "regsitel" en /home/itc/"
		echo
fi
