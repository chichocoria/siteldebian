#ifndef SITEL_H
#define SITEL_H

#define OK 0 /* Transaccion OK */
#define ABRTTIMEOUTS 1 /* Abortado por exceso de timeouts */
#define LOSTCARRIER 2 /* Perdida de portadora */
#define ABRTNAKS 3 /* Abortado por exceso de NAKs */
#define CANTINIT 4 /* No se pudo inicializar el modem */
#define CANTCONNECT 5 /* No se pudo conectar */
#define ABRTUSER 6 /* Abortado por el usuario */

#define DIRNOTFOUND 10 /* Directorio no encontrado */
#define NOMEMORY 11 /* Falta de memoria */
#define MOREARCH 12 /* Hay mas archivos de los esperados */
#define ERROPEN 13 /* No se pudo abrir archivo */
#define ERRWRITE 14 /* Error escribiendo archivo */
#define ERRCREAT 15 /* Error creando archivo */
#define ERRCONFIG 16 /* Error de configuracion */
#define ERRNOLIC 17 /* Error de licencia */
#define ERRNOMEM 18 /* No hay suficiente memoria */
#define ERRNOLOCK 19 /* Imposible crear archivo de lock para la terminal */

#endif

