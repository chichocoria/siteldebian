#!/bin/sh
##Defijir JAVA_HOME
#export JAVA_HOME=/usr/lib/jvm/jre-1.7.0-openjdk/
JAVA_HOME=/usr/lib/jvm/default-java/

if [ -z "$JAVA_HOME" ] ; then
    echo "Could not find a JDK."
    echo "Either you have to install a JDK (1.4 or up),"
    echo "or you have to set JAVA_HOME to your JDK installation directory."
    exit
fi

CP="/home/itc/jactivia/lib/jactivia.jar"
for i in /home/itc/jactivia/lib/*.jar; do
 CP=$CP:$i
done

# Reemplazar los argumentos correspondientes
ARGS="-s/home/share/data -a/home/share/activia -l/home/itc/jactivia/setup/log4jconfig.xml"

#$JAVA_HOME/bin/java -classpath jactivia.jar com.itcsoluciones.activia.JActivia $ARGS &
$JAVA_HOME/bin/java -classpath $CP com.itcsoluciones.activia.JActivia $ARGS &
