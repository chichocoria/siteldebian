				 README

		           PIActivia Java
                            Version 1.0.5
                          

El siguiente es un instructivo donde explica como es la configuraci�n
del "plug-in" para coversi�n de formatos y mecanismos con Activia.
Para obtener informaci�n actualizada remitirse a 
http://wiki.itcsoluciones.com/index.php/PiActivia

=======================================================================
                         A. PIActivia Java Introducci�n
=======================================================================

La aplicaci�n permite el procesamiento de solucitudes de autorizaci�n 
entre dos formatos y mecanismos diferentes al de ITC de manera que los 
clientes no deban rehomologar sus aplicaciones para utilizar los 
servicios de ITC.

La Configuraci�n permite modificar los par�metros sobre los cuales 
poolea sobre un directorio con estructura Activia , tomar los archivos
cuando son colocados y pasarlos a un directorio con estructura ITC. 
Adem�s de pasar los archivos de uno a otro lado, marca el archivo 
STATUS.SLT indicando que est� procesando la transacci�n (cambia la 
letra dentro del archivo) y genera un archivo _SVL.0 en el directorio 
de destino.

Sitel Cliente debe estar funcionando para que la transacci�n sea 
enviada, PIActivia solo hace las operaciones de conversi�n de formato 
y mecanismo pero no env�a los archivos.

NOTA: no es necesario crear los directorios de terminales dentro de 
path_directorio_sitel, se crean solos apartir de la estructura del 
path_directorio_activia, de esta manera no es necesario mantenerlos.

=======================================================================
                         B. Configuraci�n en Windows
=======================================================================

1) Editar el archivo "cargar.bat", modificar el par�metro "PARAM" y 
modificar los directorios, el par�metro -s corresponde a Sitel, -a
corresponde a Activia.

2) Probar si corre.

3) Si funciona, poner los mismo par�metros dentro del archivo 
"wrapper.conf" modificar el par�metro "# Application parameters" con
los mismos valores.

4) Correr "Instalar Servicio" para dejarlo corriendo.

=======================================================================
                         C. Linea de Comandos (Linux)
=======================================================================

java -jar [path]/Activia.jar 
	-s:[path_directorio_sitel] 
	-a:[path_directorio_activia] 
	-l[path_archivo_config_log4j]&
 
Par�metros:
 
[path_directorio_activia]: tiene una estructura similar a la nuestra 
en vez de TermXX se llaman TerXX y no tienen carpetas de upload ni  
download en su interior, tampoco usan un directorio TX. En esta 
estructura es donde dejar�an los archivos las terminales. Ejemplo:

directorio_activia
	|
	---> ter1
	---> ter2
	---> ter3
 
[path_directorio_sitel]: no dejar ningun subdirectorio en esta carpeta. 
En esta version si no existe la terminal en el directorio_sitel 
correspondiente a la del directorio_activa la crea, por ejemplo si no 
la de origen es Ter999 y no existe en el destino, crea la Term999, y 
los directorios de Upload y Download, esto permite que no sea necesario
mantener la aplicaci�n. Ejemplo:

directorio_sitel
	|
	---> tx

 
Por defecto toma el/los �ltimo/s paso/s utilizados en caso de que se 
ejecute sin par�metros.
 
Otras consideraciones: el TXFinder debe estar corriendo como siempre 
para que la transacci�n se haga, en una versi�n futura, ser� esta 
aplicaci�n la que directamente ejecute el cliente Sitel. El archivo 
log4j-1.2.7.jar tiene que estar en el mismo directorio que Activia.jar

=======================================================================
                         D. Determinaci�n de la Empresa (_svl.0)
=======================================================================

La versi�n 1.0.3 permite en las versiones XL de archivo Activia, 
determinar autom�ticamente la empresa y actividad con la cual debe
confeccionarse el _svl.0

La estructura del _svl.0 es: Version + Empresa + Actividad

Siendo Version un valor fijo: V901

Empresa y Actividad son obtenidos con el valor de AUMUTU (ver formato
XL de Activia) y buscando el nombre del financiador (AUMUTU) dentro del
archivo _sitel.emp, de all� se obtiene la Empresa y su Actividad.

jActivia, tomar� la primera Empresa y Actividad disponibles que 
encuentre en _sitel.emp, de lo contrario en caso de no encontrar 
asignar� un valor por default (V9011101, es decir identificar� la 
transacci�n como de OSDE, esto es debido a que versiones viejas de
Activia no tienen el campo AUMUTU).

_sitel.emp DEBE ENCONTRARSE EN EL directorio_sitel. Ese archivo DEBE
actualizarse autom�ticamente via RegSitel.

=======================================================================
ITC Soluciones S.A.
www.itcsoluciones.com
=======================================================================
